# Input Fields Detection > 2023-07-14 4:12pm
https://universe.roboflow.com/cei-l0zlv/input-fields-detection

Provided by a Roboflow user
License: CC BY 4.0

